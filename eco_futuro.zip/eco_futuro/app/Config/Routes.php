<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'home');
$routes->get('/login', 'Auth::login');
$routes->get('/logout', 'Auth::logout');
$routes->post('/auth/loginPost', 'Auth::loginPost');

$routes->get('/cadastro', 'Auth::register');
$routes->post('/auth/registerPost', 'Auth::registerPost');

$routes->get('/paginainicial', 'Paginainicial::index');

$routes->get('/cursos', 'Cursos::index');
