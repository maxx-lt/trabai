<?php

namespace App\Controllers;

class Paginainicial extends BaseController
{
    public function index()
    {
        if (!session()->has('usuario')) {
            return redirect()->to('/login');
        }

        return view('paginainicial');
    }
}
