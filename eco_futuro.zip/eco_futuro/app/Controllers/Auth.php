<?php

namespace App\Controllers;
use App\Models\UsuarioModel;
class Auth extends BaseController {
    public function login() {
        return view('login');
    }

    public function loginPost() {
        // Lógica básica de login
        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $model = new UsuarioModel();
        $usuario = $model->where('email', $email)->first();

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            session()->set('usuario', $usuario);
            return redirect()->to('/paginainicial');
        } else {
            return redirect()->back()->with('erro', 'Credenciais inválidas.');
        }
    }

    public function paginainicial() {
    if (!session()->has('usuario')) {
        return redirect()->to('/login');
    }

    return view('paginainicial/index');
}


    public function logout() {
    session()->destroy();
    return redirect()->to('/login');
}

    public function register() {
    return view('templates/header') . view('auth/login') . view('templates/footer');
}


    public function registerPost() {
        $model = new UsuarioModel();

         // Tratando o upload de foto
        $foto = $this->request->getFile('foto');
        $fotoPath = null;

        if ($foto && $foto->isValid()) {
            if ($foto->move(WRITEPATH . 'uploads')) {
                $fotoPath = $foto->getName();
            }
        }


        $data = [
            'cpf' => $this->request->getPost('cpf'),
            'usuario' => $this->request->getPost('usuario'),
            'nome_completo' => $this->request->getPost('nome_completo'),
            'email' => $this->request->getPost('email'),
            'senha' => password_hash($this->request->getPost('senha'), PASSWORD_DEFAULT),
            'data_nascimento' => $this->request->getPost('data_nascimento'),
            'nome_exibicao' => $this->request->getPost('nome_exibicao'),
            'bio' => $this->request->getPost('bio'),
            'foto' => $fotoPath, // Caminho da foto no servidor
        ];

        $model->insert($data);
        return redirect()->to('/login');
    }
}