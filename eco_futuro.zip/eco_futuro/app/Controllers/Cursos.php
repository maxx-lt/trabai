<?php

namespace App\Controllers;
class Cursos extends BaseController {
    public function index() {
        return view('cursos');
    }
}