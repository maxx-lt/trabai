<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css/header.css') ?>" rel="stylesheet">
</head>
<body>

<body>

<header>
    <div class="logo">
        <a href="<?= base_url('/') ?>">EcoFuturo</a>
    </div>
    <nav>
        <ul>
            <?php if (session()->has('usuario')): ?>
            <li><a href="<?= base_url('/') ?>">Home</a></li>
            <!-- <li><a href="<?= base_url('cursos') ?>">Meus cursos</a></li> -->
            <li><a href="<?= base_url('logout') ?>">Sair</a></li>

            <?php else: ?>
            
            <li><a href="<?= base_url('/') ?>">Home</a></li>
            <li><a href="<?= base_url('cursos') ?>">Cursos</a></li>
            <li><a href="<?= base_url('login') ?>">Login</a></li>

            <?php endif; ?>

        </ul>
    </nav>
</header>

</body>
</html>