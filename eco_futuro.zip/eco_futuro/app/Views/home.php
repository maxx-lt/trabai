 

    <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo | Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Raleway', sans-serif;
        }

        .hero {
            height: 100vh;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(255, 255, 255, 0.2)), url('https://images.unsplash.com/photo-1508780709619-79562169bc64') no-repeat center center/cover;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 20px;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
        }

        .section {
            padding: 60px 20px;
        }

        .planos {
            background: white;
            text-align: center;
        }

        .carrossel {
            background: #f1f1f1;
            text-align: center;
        }

        .carousel-item img {
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<?= view('layouts/header') ?>

    <section class="hero">
        <h1>Bem-vindo ao EcoFuturo</h1>
        <p>Uma plataforma de cursos pensada para transformar a relação com o meio ambiente. Aprenda sobre sustentabilidade, inovação ecológica e seja parte da mudança!</p>
    </section>

    <section class="section planos">
        <h2>Planos de Assinatura</h2>
        <p>Escolha o plano que mais combina com você e tenha acesso completo aos nossos conteúdos exclusivos.</p>
        <div class="row justify-content-center mt-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Plano Básico</h5>
                        <p class="card-text">Acesso a conteúdos introdutórios por R$19,90/mês.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Plano Pro</h5>
                        <p class="card-text">Conteúdo completo e certificado por R$39,90/mês.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section carrossel">
        <h2>Nossos Cursos em Destaque</h2>
        <div id="carouselCursos" class="carousel slide mt-4" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://images.unsplash.com/photo-1581090700227-1e8b43f2a7e6" class="d-block w-75 mx-auto" alt="Curso 1">
                    <p class="mt-3">Curso de Energia Solar para Iniciantes</p>
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1600585154356-596af9009e5b" class="d-block w-75 mx-auto" alt="Curso 2">
                    <p class="mt-3">Agricultura Urbana Sustentável</p>
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1578926375605-eaf7559b1458" class="d-block w-75 mx-auto" alt="Curso 3">
                    <p class="mt-3">Zero Waste no Dia a Dia</p>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselCursos" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Anterior</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselCursos" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Próximo</span>
            </button>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    
    <?= view('layouts/footer') ?>


</body>
</html>