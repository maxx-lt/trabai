<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo | Login e Cadastro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- links -->
    <link href="<?= base_url('assets/css/login.css') ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>

<body>
    <div class="logo">
        <a href="<?= base_url('/') ?>">EcoFuturo</a>
    </div>

<div class="form-container">
    <!-- Formulário de Login -->
    <div class="form-box" id="loginForm">

        <h2>Bem vindo de volta!</h2>
        <form action="<?= base_url('auth/loginPost') ?>" method="POST">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required>
            </div>
            <button type="submit">Entrar</button>
            <br>
            <p>Não tem uma conta? <a href="#" id="showCadastro">Cadastre-se</a></p>
        </form>
    </div>

    <!-- Formulário de Cadastro (inicialmente oculto) -->
    <div class="form-box" id="cadastroForm">
        <h2>Contribua para o nosso EcoFuturo!</h2>
        <form action="<?= base_url('auth/registerPost') ?>" method="POST" enctype="multipart/form-data">
            <div class="input-group">
                <label for="cpf">CPF:</label>
                <input type="text" name="cpf" id="cpf" maxlength="11" required>
            </div>
            <div class="input-group">
                <label for="usuario">Nome de usuário:</label>
                <input type="text" name="usuario" id="usuario" required>
            </div>
            <div class="input-group">
                <label for="nome_completo">Nome Completo:</label>
                <input type="text" name="nome_completo" id="nome_completo" required>
            </div>
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required>
            </div>
            <div class="input-group">
                <label for="data_nascimento">Data de Nascimento:</label>
                <input type="date" name="data_nascimento" id="data_nascimento" required>
            </div>

            <button type="button" id="showCadastro2">Continuar</button>
            <br>
            <p>Já tem uma conta? <a href="#" id="showLogin">Entre aqui</a></p>
        </form>
    </div>

    <div class="form-box" id="cadastroForm2">
        <h2>Personalize seu perfil</h2>
        <form action="<?= base_url('auth/registerPost') ?>" method="POST" enctype="multipart/form-data">

            <div class="input-group">
                <label for="foto">Foto:</label>
                <input type="file" name="foto" id="foto">
            </div>
            <div class="input-group">
                <label for="nome_exibicao">Nome de Exibição:</label>
                <input type="text" name="nome_exibicao" id="nome_exibicao">
            </div>
            <div class="input-group">
                <label for="bio">Bio:</label>
                <textarea name="bio" id="bio"></textarea>
            </div>
            
            <button type="submit">Cadastrar</button>
            <br>
            <p>Já tem uma conta? <a href="#" id="showLogin">Entre aqui</a></p>
        </form>
    </div>
</div>

<?php if (session()->getFlashdata('erro')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('erro') ?>
    </div>
<?php endif; ?>
<?php if (session()->getFlashdata('sucesso')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('sucesso') ?>
    </div>
<?php endif; ?>


<script>
    const showCadastro = document.getElementById('showCadastro');
    const showLogin = document.getElementById('showLogin');
    const showCadastro2 = document.getElementById('showCadastro2');

    const loginForm = document.getElementById('loginForm');     // agora pegando certo
    const cadastroForm = document.getElementById('cadastroForm');
    const cadastroForm2 = document.getElementById('cadastroForm2');


    showCadastro.addEventListener('click', () => {
        loginForm.style.display = 'none';
        cadastroForm.style.display = 'block';
        cadastroForm2.style.display = 'none'; // garantir que não fique visível
    });

    showLogin.addEventListener('click', () => {
        cadastroForm.style.display = 'none';
        cadastroForm2.style.display = 'none';
        loginForm.style.display = 'block';
    });

    showCadastro2.addEventListener('click', () => {
        cadastroForm.style.display = 'none';
        cadastroForm2.style.display = 'block';
    });
</script>



    

</body>
</html>