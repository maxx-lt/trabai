<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo | Home</title>
</head>
<body>
    <?= view('layouts/header') ?>

    <?php if (session()->has('usuario')): ?>
        <p>Bem-vindo, <?= esc(session('usuario')['nome_exibicao']) ?>!</p>
    <?php endif; ?>



    
    <?= view('layouts/footer') ?>


</body>
</html>